<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="bg-white">
        <div class="max-w-2xl mx-auto py-16 px-4 sm:py-24 sm:px-6 lg:max-w-7xl lg:px-8">
          <h2 class="text-2xl font-extrabold tracking-tight text-gray-900">BIENVENIDO AL PANEL DE CONTROL DE LA SUCURSAL DE <?php echo e($departamento[0]->Departamento); ?></h2>
          <?php if(auth()->check() && auth()->user()->hasRole('administrador')): ?>
          <div class="mt-6 grid grid-cols-1 gap-y-10 gap-x-6 sm:grid-cols-2 lg:grid-cols-4 xl:gap-x-8">
            <a href="<?php echo e(route('encargado.create',['req'=>$departamento[0]])); ?>" class="group relative">
              <div class="w-full min-h-80 bg-gray-200 aspect-w-1 aspect-h-1 rounded-md overflow-hidden group-hover:opacity-75 lg:h-80 lg:aspect-none">
                <img src="https://static.vecteezy.com/system/resources/previews/000/377/948/non_2x/add-user-vector-icon.jpg" alt="Front of men&#039;s Basic Tee in black." class="w-full h-full object-center object-cover lg:w-full lg:h-full">
              </div>
              <div class="mt-4 flex justify-between">
                <div class="flex w-full justify-center items-center">
                  <h3 class="text-xl flex w-full text-center text-gray-700">
                      OPCIONES DE ENCARGADOS DE RED UNO SUR
                  </h3>
                </div>
              </div>
            </a>

            <a href="<?php echo e(route('personal.create',['req'=>$departamento[0]])); ?>" class="group relative">
                <div class="w-full min-h-80 bg-gray-200 aspect-w-1 aspect-h-1 rounded-md overflow-hidden group-hover:opacity-75 lg:h-80 lg:aspect-none">
                  <img src="https://cdn2.iconfinder.com/data/icons/flat-style-svg-icons-part-2/512/add_user_group-512.png" alt="Front of men&#039;s Basic Tee in black." class="w-full h-full object-center object-cover lg:w-full lg:h-full">
                </div>
                <div class="mt-4 flex justify-between">
                  <div class="flex w-full justify-center items-center">
                    <h3 class="text-xl flex w-full text-center text-gray-700">
                        OPCIONES DE PERSONAL RED UNO SUR
                    </h3>
                  </div>
                </div>
            </a>

            <a href="<?php echo e(route('unidad.create',['req'=>$departamento[0]])); ?>" class="group relative">
                <div class="w-full min-h-80 bg-gray-200 aspect-w-1 aspect-h-1 rounded-md overflow-hidden group-hover:opacity-75 lg:h-80 lg:aspect-none">
                  <img src="https://milagrosruizbarroeta.com/wp-content/uploads/2019/12/017-management.png" alt="Front of men&#039;s Basic Tee in black." class="w-full h-full object-center object-cover lg:w-full lg:h-full">
                </div>
                <div class="mt-4 flex justify-between">
                  <div class="flex w-full justify-center items-center">
                    <h3 class="text-xl flex w-full text-center text-gray-700">
                        UNIDADES DE RED UNO SUR
                    </h3>
                  </div>
                </div>
              </a>


            <div class="group relative">
                <div class="w-full min-h-80 bg-gray-200 aspect-w-1 aspect-h-1 rounded-md overflow-hidden group-hover:opacity-75 lg:h-80 lg:aspect-none">
                  <img src="https://cdn-icons-png.flaticon.com/512/2897/2897785.png" alt="Front of men&#039;s Basic Tee in black." class="w-full h-full object-center object-cover lg:w-full lg:h-full">
                </div>
                <div class="mt-4 flex justify-between">
                  <div class="flex w-full justify-center items-center">
                    <h3 class="text-xl flex w-full text-center text-gray-700">
                        INVENTARIO DE RED UNO SUR
                    </h3>
                  </div>
                </div>
            </div>


            <div class="group relative">
                <div class="w-full min-h-80 bg-gray-200 aspect-w-1 aspect-h-1 rounded-md overflow-hidden group-hover:opacity-75 lg:h-80 lg:aspect-none">
                  <img src="https://cdn-icons-png.flaticon.com/512/166/166913.png" alt="Front of men&#039;s Basic Tee in black." class="w-full h-full object-center object-cover lg:w-full lg:h-full">
                </div>
                <div class="mt-4 flex justify-between">
                  <div class="flex w-full justify-center items-center">
                    <h3 class="text-xl flex w-full text-center text-gray-700">
                        PRODUCTOS DE RED UNO SUR
                    </h3>
                  </div>
                </div>
            </div>

            <div class="group relative">
              <div class="w-full min-h-80 bg-gray-200 aspect-w-1 aspect-h-1 rounded-md overflow-hidden group-hover:opacity-75 lg:h-80 lg:aspect-none">
                <img src="https://cdn-icons-png.flaticon.com/512/4318/4318881.png" alt="Front of men&#039;s Basic Tee in black." class="w-full h-full object-center object-cover lg:w-full lg:h-full">
              </div>
              <div class="mt-4 flex justify-between">
                <div class="flex w-full justify-center items-center">
                  <h3 class="text-xl flex w-full text-center text-gray-700">
                      REMISION DE MATERIALES DE RED UNO SUR
                  </h3>
                </div>
              </div>
            </div>

            <div class="group relative">
              <div class="w-full min-h-80 bg-gray-200 aspect-w-1 aspect-h-1 rounded-md overflow-hidden group-hover:opacity-75 lg:h-80 lg:aspect-none">
                <img src="https://cdn-icons-png.flaticon.com/512/1055/1055644.png" alt="Front of men&#039;s Basic Tee in black." class="w-full h-full object-center object-cover lg:w-full lg:h-full">
              </div>
              <div class="mt-4 flex justify-between">
                <div class="flex w-full justify-center items-center">
                  <h3 class="text-xl flex w-full text-center text-gray-700">
                      REPORTES DE RED UNO SUR
                  </h3>
                </div>
              </div>
            </div>
          <?php endif; ?>
          <?php if(auth()->check() && auth()->user()->hasRole('encargado')): ?>
          <div class="mt-6 grid grid-cols-1 gap-y-10 gap-x-6 sm:grid-cols-2 lg:grid-cols-4 xl:gap-x-8">
          <div class="group relative">
            <div class="w-full min-h-80 bg-gray-200 aspect-w-1 aspect-h-1 rounded-md overflow-hidden group-hover:opacity-75 lg:h-80 lg:aspect-none">
              <img src="https://cdn-icons-png.flaticon.com/512/4318/4318881.png" alt="Front of men&#039;s Basic Tee in black." class="w-full h-full object-center object-cover lg:w-full lg:h-full">
            </div>
            <div class="mt-4 flex justify-between">
              <div class="flex w-full justify-center items-center">
                <h3 class="text-xl flex w-full text-center text-gray-700">
                    REMISION DE MATERIALES DE RED UNO SUR
                </h3>
              </div>
            </div>
          </div>

          <div class="group relative">
            <div class="w-full min-h-80 bg-gray-200 aspect-w-1 aspect-h-1 rounded-md overflow-hidden group-hover:opacity-75 lg:h-80 lg:aspect-none">
              <img src="https://cdn-icons-png.flaticon.com/512/1055/1055644.png" alt="Front of men&#039;s Basic Tee in black." class="w-full h-full object-center object-cover lg:w-full lg:h-full">
            </div>
            <div class="mt-4 flex justify-between">
              <div class="flex w-full justify-center items-center">
                <h3 class="text-xl flex w-full text-center text-gray-700">
                    REPORTES
                </h3>
              </div>
            </div>
          </div>
          <?php endif; ?>
            <!-- More products... -->
          </div>
        </div>
      </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\laragon\www\InventarioRedUnoSur\resources\views/pagina_admin/dashboard.blade.php ENDPATH**/ ?>