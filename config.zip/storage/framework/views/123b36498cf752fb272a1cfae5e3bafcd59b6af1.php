<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>RED UNO SUR</title>
        <link rel="stylesheet" href="<?php echo e(asset('css/homeinit.css')); ?>">
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@200&display=swap" rel="stylesheet">
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Piedra&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"/>
        <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    </head>
    <body>
        <header class="bg_animate">
            <div class="header_nav">
                <div class="contenedor">
                    <img class="imagen-navegador" src="<?php echo e(asset('image/logo.png')); ?>" alt="">
                    <nav class="navegador-principal">
                            <?php if(Route::has('login')): ?>
                            <div class="navegador-items" style="margin: 15px">
                                <?php if(auth()->guard()->check()): ?>
                                    <a href="<?php echo e(url('/sucursal')); ?>" class=""><i class="fas fa-tachometer-alt"></i>PAGINA PRINCIPAL</a>
                                <?php else: ?>
                                    <a href="<?php echo e(route('login')); ?>" class=""> <i class="fas fa-user"></i> INICIAR SESION</a>
                                <?php endif; ?>
                            </div>
                            <?php endif; ?>
                    </nav>
                </div>
            </div>


            <section class="banner contenedor">
                <section class="banner_title">
                    <h2 class="letras-header animate__animated animate__zoomIn">
                        <span class="lh">RED</span>
                        <span class="lh"> - </span>
                        <span class="lh">UNO</span>
                    </h2>
                    <h3 class="letras-header-sc animate__animated animate__slideInLeft">Somos lo mejor de Bolivia</h3>
                </section>
                <div class="banner_img">
                    <img class="animate__animated animate__zoomInDown" src="https://pbs.twimg.com/profile_images/1413965183601549313/BsTOORL6_400x400.jpg" style="width: 25rem; border-radius:50%;" alt="">
                </div>
            </section>
            <div class="burbujas">
                <div class="burbuja"></div>
                <div class="burbuja"></div>
                <div class="burbuja"></div>
                <div class="burbuja"></div>
                <div class="burbuja"></div>
                <div class="burbuja"></div>
                <div class="burbuja"></div>
                <div class="burbuja"></div>
                <div class="burbuja"></div>
                <div class="burbuja"></div>
            </div>
        </header>
    </body>
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script src="https://kit.fontawesome.com/102099bbc5.js" crossorigin="anonymous"></script>
    <script defer>
        AOS.init();
    </script>
</html>
<?php /**PATH C:\laragon\www\InventarioRedUnoSur\resources\views/welcome.blade.php ENDPATH**/ ?>