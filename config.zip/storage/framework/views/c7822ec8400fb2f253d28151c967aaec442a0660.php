<a href="/">
  <img src="https://pbs.twimg.com/profile_images/1413965183601549313/BsTOORL6_400x400.jpg" style="width: 3rem; border-radius:50%;">
</a>
<?php /**PATH C:\laragon\www\InventarioRedUnoSur\resources\views/vendor/jetstream/components/application-mark.blade.php ENDPATH**/ ?>