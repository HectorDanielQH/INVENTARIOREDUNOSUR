<x-app-layout>
    @livewire('personal-live',['departamento'=>$dato])
</x-app-layout>