<?php return array (
  'calculadora' => 'App\\Http\\Livewire\\Calculadora',
  'encargado-live' => 'App\\Http\\Livewire\\EncargadoLive',
  'personal-live' => 'App\\Http\\Livewire\\PersonalLive',
  'sucursales' => 'App\\Http\\Livewire\\Sucursales',
  'unidad-live' => 'App\\Http\\Livewire\\UnidadLive',
);