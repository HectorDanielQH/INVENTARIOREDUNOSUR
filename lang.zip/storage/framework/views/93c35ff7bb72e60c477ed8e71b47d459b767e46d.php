<a href="/">
  <img src="<?php echo e(asset('images/og_image.jpg')); ?>" style="width: 3rem; border-radius:50%;">
</a>
<?php /**PATH C:\laragon\www\INVENTARIOREDUNOSUR\resources\views/vendor/jetstream/components/application-mark.blade.php ENDPATH**/ ?>