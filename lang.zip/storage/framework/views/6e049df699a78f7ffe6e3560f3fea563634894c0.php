<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<div>
    <!----------| Remision tailwind |---------->
    <!---------- titulo encabezado con tailwind ---------->
    <div class="container mx-auto mt-5">
        <div class="flex flex-wrap mx-3">
            <div class="w-full px-3">
                <div class="bg-orange-400 shadow-md rounded px-8 pt-6 pb-8 mb-4">
                    <div class="flex flex-wrap -mx-3">
                        <div class="w-full flex flex-col justify-center items-center px-3">
                            <h1 class="text-2xl 
                            text-white
                            font-bold text-center">
                                VISUALIZACION DE REMISIÓN
                                <br/>
                                <?php echo e(__('EMPLEADO: ')); ?><?php echo e($remisiones[0]->personal->nombre); ?> <?php echo e($remisiones[0]->personal->apellido); ?>

                                <br/>
                                <?php echo e(__('REMISIÓN NUMERO: ')); ?><?php echo e($remisiones[0]->numRemision); ?>

                            </h1>
                            <?php if($remisiones[0]->fechadevolucion==null): ?>
                                <div class="
                                w-full
                                flex
                                justify-around
                                ">
                                    <a 
                                    href="<?php echo e(redirect()->back()->getTargetUrl()); ?>"
                                    class="bg-orange-500 hover:bg-orange-700 shadow-md shadow-gray-600 text-white font-bold py-2 px-4 rounded float-right mt-4">
                                        <i class="fas fa-arrow-left"></i>
                                        VOLVER
                                    </a>
                                    <a
                                        href="<?php echo e(route('pdfremision',['remision'=>$remisiones[0]->numRemision,'dato'=>$remisiones[0]->personal->departamento])); ?>"
                                        target="_blank"
                                        class="bg-blue-500 hover:bg-blue-700 shadow-md shadow-gray-600 text-white font-bold py-2 px-4 rounded float-right mt-4">
                                        GENERAR PDF
                                    </a>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!----------| fin titulo encabezado con tailwind |---------->

    <!----------|tabla remision con tailwind |---------->
    <div class="container mx-auto mt-5">
        <div class="flex flex-wrap mx-3">
            <div class="w-full px-3">
                <div class="bg-orange-400 shadow-md rounded px-8 pt-6 pb-8 mb-4">
                    <div class="flex flex-wrap -mx-3">
                        <div class="w-full px-3">
                            <table class="table-auto w-full">
                                <thead>
                                    <tr class="bg-gray-100">
                                        <th class="px-4 py-2">COD. MAT.</th>
                                        <th class="px-4 py-2">DESCRIPCION</th>
                                        <th class="px-4 py-2">CANT. PRESTADA</th>
                                        <th class="px-4 py-2">ESTADO DEL PROD. ANTERIOR</th>
                                        <th class="px-4 py-2">FECHA DE PRESTAMO</th>
                                        <th class="px-4 py-2">FECHA DE DEVOLUCIÓN</th>
                                        <th class="px-4 py-2">DETALLE DEL PROD. DEVUELTO</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $remisiones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $remision): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="bg-slate-300">
                                        <td class="border px-4 py-2"><?php echo e($remision->inventario->codigo); ?></td>
                                        <td class="border px-4 py-2"><?php echo e($remision->inventario->detalle); ?></td>
                                        <td class="border px-4 py-2"><?php echo e($remision->cantidad); ?></td>
                                        <td class="border px-4 py-2">
                                            <?php switch($remision->inventario->estado):
                                                case (1): ?>
                                                    <?php echo e('DE BAJA'); ?>

                                                    <?php break; ?>
                                                <?php case (2): ?>
                                                    <?php echo e('MALO'); ?>

                                                    <?php break; ?>
                                                <?php case (3): ?>
                                                    <?php echo e('BUENO'); ?>

                                                    <?php break; ?>
                                                <?php case (4): ?>
                                                    <?php echo e('MUY BUENO'); ?>

                                                    <?php break; ?>
                                                <?php case (5): ?>
                                                    <?php echo e('NUEVO'); ?>

                                                    <?php break; ?>
                                                <?php default: ?>
                                                    <?php echo e('NO DEFINIDO'); ?>    
                                            <?php endswitch; ?>
                                        </td>
                                        <td class="border px-4 py-2"><?php echo e($remision->created_at->format('d-m-Y')); ?></td>
                                        <td class="border px-4 py-2">
                                            <?php if($remision->fechadevolucion==null): ?>
                                                <?php echo e('NO DEVUELTO'); ?>

                                            <?php else: ?>
                                                <?php echo e($remision->fechadevolucion); ?>

                                            <?php endif; ?>
                                        </td>
                                        <td class="border px-4 py-2">
                                            <?php if($remision->detalledevolucion==null): ?>
                                                <?php echo e('NO DEVUELTO'); ?>

                                            <?php else: ?>
                                                <?php echo e($remision->detalledevolucion); ?>

                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\INVENTARIOREDUNOSUR\resources\views/visualizarremision.blade.php ENDPATH**/ ?>