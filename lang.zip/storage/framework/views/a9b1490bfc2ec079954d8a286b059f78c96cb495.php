<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>REPORTE</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
</head>
<body>
    <div class="">
        <img
            style=" height: 80px;"
            src="<?php echo e(asset('images/pdf.png')); ?>" alt="">    
    </div>
    <div>
        <h1 class="
            text-center
        "
        style="font-size: 30px; font-weight: bold; font-family: Robot, sans-serif;"
        >
            RED UNO SUR
        </h1>
        <h2 class="
            text-center
        "
        style="font-size: 20px; font-weight: bold; font-family: Robot, sans-serif;"

        >
            REMISIÓN DE MATERIALES
        </h2>
    </div>
    <br>
    <div>
        <h3 
            style="font-size: 15px; font-weight: bold; font-family: Robot, sans-serif;"
        >
            Para el personal: <?php echo e($remisiones[0]->personal->nombre); ?> <?php echo e($remisiones[0]->personal->apellido); ?>

        </h3>
        <h3
            style="font-size: 15px; font-weight: bold; font-family: Robot, sans-serif;"
        >
            Remisión número: <?php echo e($remisiones[0]->numRemision); ?>

        </h3>
        <h3 
            style="font-size: 15px; font-weight: bold; font-family: Robot, sans-serif;"
        >
            Fecha de prestamo: <?php echo e($remisiones[0]->created_at->format('d/m/Y')); ?>

        </h3>
        <h3 
            style="font-size: 15px; font-weight: bold; font-family: Robot, sans-serif;"
        >
            Departamento de prestamo: <?php echo e($remisiones[0]->departamentos->Departamento); ?>

        </h3>
        <br>
    </div>

    <div>
        <h4
            style="font-size: 12px; color:blue; font-weight: bold; font-family: Robot, sans-serif;"
        >
            Adjunto a la presente, nos permitimos enviar y/o devolver el siguiente material
        </h4>
    </div>

    <div>
        <table 
            class="table table-bordered"
            style="border: 1px solid black;"
        >
            <thead>
                <tr style="
                    border: 1px solid black;
                    font-size: 15px;
                    font-weight: bold;
                    font-family: Robot, sans-serif;
                    text-align: center;
                    "
                >
                    <th style="
                    border: 1px solid black;
                ">COD. MAT.</th>
                    <th style="
                    border: 1px solid black;
                ">CANT. PRESTADA</th>
                    <th style="
                    border: 1px solid black;
                ">DESCRIPCION</th>
                    <th style="
                    border: 1px solid black;
                ">ESTADO DEL PROD. PRESTADO</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $remisiones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $remision): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr
                    style="
                        border: 1px solid black;
                        font-size: 15px;
                        font-family: Robot, sans-serif;
                        text-align: center;
                    "
                >
                    <td style="
                    border: 1px solid black;
                "><?php echo e($remision->inventario->codigo); ?></td>
                    <td style="
                    border: 1px solid black;
                "><?php echo e($remision->cantidad); ?></td>
                    <td style="
                    border: 1px solid black;
                "><?php echo e($remision->inventario->detalle); ?></td>
                    <td style="
                    border: 1px solid black;
                ">
                        <?php switch($remision->inventario->estado):
                            case (1): ?>
                                <?php echo e('DE BAJA'); ?>

                                <?php break; ?>
                            <?php case (2): ?>
                                <?php echo e('MALO'); ?>

                                <?php break; ?>
                            <?php case (3): ?>
                                <?php echo e('BUENO'); ?>

                                <?php break; ?>
                            <?php case (4): ?>
                                <?php echo e('MUY BUENO'); ?>

                                <?php break; ?>
                            <?php case (5): ?>
                                <?php echo e('NUEVO'); ?>

                                <?php break; ?>
                        <?php endswitch; ?>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <br>
    <br>
    <br>
    <br>
    <div>
        <h3 style="
                    font-size: 15px;
                    font-weight: bold;
                    font-family: Robot, sans-serif;
                    text-align: center;
                    ">.................................</h3>
        <h3 style="
                    font-size: 15px;
                    font-weight: bold;
                    font-family: Robot, sans-serif;
                    text-align: center;
                    ">Emisor</h3>
    </div>
</body>
</html><?php /**PATH C:\laragon\www\INVENTARIOREDUNOSUR\resources\views/pdfremision.blade.php ENDPATH**/ ?>