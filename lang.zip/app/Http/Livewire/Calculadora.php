<?php

namespace App\Http\Livewire;

use Livewire\Component;

class Calculadora extends Component
{
    public function render()
    {
        return view('livewire.calculadora');
    }
}
