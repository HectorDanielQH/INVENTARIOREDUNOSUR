<?php return array (
  'calculadora' => 'App\\Http\\Livewire\\Calculadora',
  'encargado-live' => 'App\\Http\\Livewire\\EncargadoLive',
  'inventario-live' => 'App\\Http\\Livewire\\InventarioLive',
  'personal-live' => 'App\\Http\\Livewire\\PersonalLive',
  'remision-crear-live' => 'App\\Http\\Livewire\\RemisionCrearLive',
  'remision-live' => 'App\\Http\\Livewire\\RemisionLive',
  'reportes-admin-live' => 'App\\Http\\Livewire\\ReportesAdminLive',
  'sucursales' => 'App\\Http\\Livewire\\Sucursales',
  'unidad-live' => 'App\\Http\\Livewire\\UnidadLive',
);