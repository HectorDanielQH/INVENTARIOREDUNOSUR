<x-app-layout>
    @livewire('inventario-live',['departamento'=>$dato])
</x-app-layout>
