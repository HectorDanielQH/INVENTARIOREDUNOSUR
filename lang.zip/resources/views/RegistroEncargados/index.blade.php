<x-app-layout>
    @livewire('encargado-live',['departamento'=>$dato])
</x-app-layout>
