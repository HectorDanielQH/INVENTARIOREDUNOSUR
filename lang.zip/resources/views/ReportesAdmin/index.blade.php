<x-app-layout>
    @livewire('reportes-admin-live',['departamento'=>$dato])
</x-app-layout>