<x-app-layout>
    @livewire('sucursales')
</x-app-layout>