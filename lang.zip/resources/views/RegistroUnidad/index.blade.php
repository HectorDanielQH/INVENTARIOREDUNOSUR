<x-app-layout>
    @livewire('unidad-live',['departamento'=>$dato])
</x-app-layout>