<x-app-layout>
    @livewire('remision-live',['departamento'=>$dato])
</x-app-layout>
