<x-app-layout>
    @livewire('remision-crear-live',['departamento'=>$dato])
</x-app-layout>
